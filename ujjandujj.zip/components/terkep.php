<div class="container">
        <h1 class="aranySzoveg text-center mt-4">Irodánk elérhetősége</h1>
        <h4 class="aranySzoveg">Hosszabb leiras honnan mivel lehet megkozeliteni</h4>

        <br>

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d476.35074173929974!2d19.07415826590995!3d47.516270947807534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4741db8833124cab%3A0x61ecedd159a53bf!2zQnVkYXBlc3QsIETDs3pzYSBHecO2cmd5IMO6dCAxMDgsIDEwNjg!5e0!3m2!1shu!2shu!4v1707604120120!5m2!1shu!2shu" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>