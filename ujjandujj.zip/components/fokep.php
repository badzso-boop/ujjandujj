<div id="fokep" class="position-relative" style="margin-top: -2px;">
    <img src="img/fo.jpg" alt="" class="w-100 mx-auto d-block">
    <div class="position-absolute w-100 h-100 sotet"></div>
    <div class="position-absolute start-50 translate-middle text-center text-white" style="bottom: 10%; z-index: 2">
        <h4 class="d-none d-md-block aranySzoveg" style="text-shadow: black 1px 0 10px;">Ujj & Ujj & Partners Ügyvédi Iroda</h4>
        <h4 class="d-md-none mb-0 aranySzoveg" style="text-shadow: black 1px 0 10px;">Ujj & Ujj & Partners Ügyvédi Iroda</h4>
        <p class="mb-0 aranySzoveg" style="bottom: -100%; position: absolute; width: 100%;text-shadow: black 1px 0 10px;">Minőség, Hitelesség, Precizitás</p>
    </div>
</div>